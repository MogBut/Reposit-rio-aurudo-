# Noturno — gerar o APK

Esse pacote tem o código pronto de um app Android (WebView) que carrega
seu "Noturno" (senha + notas) dentro de um app nativo, funcionando offline.

## O que você precisa
- Instalar o **Android Studio** (gratuito): https://developer.android.com/studio
- Ter uns 15–20 minutos na primeira vez (o Android Studio baixa componentes)

## Passo a passo

1. Abra o Android Studio → **New Project** → escolha **Empty Views Activity**
   (não "Empty Activity" do Compose — tem que ser a versão com `Views`).
2. Preencha:
   - **Name:** Noturno
   - **Package name:** com.noturno.app
   - **Language:** Kotlin
   - **Minimum SDK:** API 24
   - Se aparecer a opção **"Use Kotlin DSL build scripts"**, **desmarque** ela
     (deixe no padrão Groovy `.gradle`), para bater com os arquivos deste pacote.
3. Clique em **Finish** e espere o projeto abrir e sincronizar.
4. No painel à esquerda (modo **Project**, não **Android**), localize a pasta
   do projeto que foi criada no seu computador (geralmente em
   `AndroidStudioProjects/Noturno`).
5. Com o Android Studio **fechado** (ou usando o explorador de arquivos do
   sistema), substitua/copie os arquivos deste pacote para dentro da pasta
   do projeto, mantendo os mesmos caminhos:
   - `app/src/main/assets/index.html` → copiar (crie a pasta `assets` se
     não existir)
   - `app/src/main/java/com/noturno/app/MainActivity.kt` → substituir
   - `app/src/main/res/layout/activity_main.xml` → substituir
   - `app/src/main/res/values/strings.xml` → substituir
   - `app/src/main/res/values/themes.xml` → substituir
   - `app/src/main/AndroidManifest.xml` → substituir
   - `app/build.gradle` → substituir
   - `build.gradle` (da raiz do projeto) → substituir
6. Abra o Android Studio de novo nesse projeto. Ele vai pedir para
   **Sync Now** — clique para sincronizar.
7. Gere o APK: menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Quando terminar, vai aparecer um aviso "APK(s) generated successfully".
   Clique em **locate** para abrir a pasta — o arquivo estará em:
   `app/build/outputs/apk/debug/app-debug.apk`
9. Transfira esse `.apk` pro seu celular (cabo USB, Google Drive, WhatsApp
   pra você mesmo, etc.) e instale (pode ser preciso permitir
   "instalar de fontes desconhecidas" nas configurações do Android).

## Observações
- Esse é um APK de **debug**, ótimo para instalar no seu próprio celular.
  Se um dia quiser publicar na Play Store, o Android Studio também gera
  um APK/AAB "assinado" (**Build → Generate Signed Bundle / APK**).
- As notas ficam salvas dentro do app (armazenamento local do WebView),
  então continuam lá mesmo sem internet. Internet só é usada (se
  disponível) pra carregar as fontes do Google Fonts na abertura.
- Se quiser trocar a senha "1920" ou mexer no visual, é só editar o
  arquivo `app/src/main/assets/index.html` e gerar o APK de novo.

## Aba "Dev" (pareamento + injeção de resolução)

Essa aba fica dentro do bloco de notas, ao lado de "Notas". Ela usa a
biblioteca **dadb** (`dev.mobile:dadb` / `dev.mobile:dadb-android`), a
mesma usada por ferramentas como o Maestro, pra falar o protocolo ADB
direto do app — sem precisar de PC nem do binário `adb`.

**Aviso honesto:** eu não tenho um ambiente com Android SDK aqui para
compilar e testar esse pedaço de verdade. O fluxo está certo (parear →
conectar → `wm size` / `wm density` via shell), mas em
`AdbBridge.kt` tem 2-3 linhas marcadas com `// confira` onde o nome
exato do método pode variar um pouco entre versões da biblioteca — é
só abrir o arquivo no Android Studio, e se der erro de "unresolved
reference" nessas linhas, usar o autocomplete (Ctrl+Espaço) pra achar
o nome certo (ex.: `Dadb.pair(...)` ou `AdbKeyPair.generate()` podem
ter assinaturas ligeiramente diferentes na versão que o Gradle baixar).
Uma vez resolvidas essas 2-3 linhas, o resto já está pronto.

### Como usar
1. No celular, vá em **Configurações → Opções do desenvolvedor →
   Depuração sem fio** e ative.
2. Toque em **"Parear dispositivo com código de pareamento"** — vai
   mostrar um IP:porta e um código de 6 dígitos. Coloque isso nos
   campos de **pareamento** da aba Dev.
3. Volte pra tela principal de "Depuração sem fio" — lá tem outro
   IP:porta (o de **conexão**, diferente do de pareamento). Coloque
   nos campos de **conexão**.
   - Como o app está rodando no próprio celular que você quer
     controlar, o IP costuma funcionar tanto com o IP Wi-Fi mostrado
     na tela quanto com `127.0.0.1` (localhost) — se um não
     conectar, tenta o outro.
4. Toque em **"Parear e conectar"**. O status muda pra "conectado".
5. Os campos de resolução já vêm preenchidos com `3608x1630` e
   densidade `300`. Toque em **"Injetar resolução"**.
6. **"Resetar resolução e densidade"** desfaz os dois de uma vez
   (`wm size reset` + `wm density reset`).

O log dentro da aba mostra cada comando executado e o resultado.
