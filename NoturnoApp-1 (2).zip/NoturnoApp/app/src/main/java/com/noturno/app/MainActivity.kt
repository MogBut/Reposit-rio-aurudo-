package com.noturno.app

import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Evita que a tela apague sozinha enquanto o app está aberto
        // (opcional - remova a linha abaixo se não quiser isso)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = findViewById(R.id.webview)

        webView.settings.apply {
            javaScriptEnabled = true          // o app usa JS (senha, raios, notas)
            domStorageEnabled = true          // necessário para o localStorage das notas
            databaseEnabled = true
            allowFileAccess = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        // Mantém a navegação dentro do próprio WebView
        webView.webViewClient = WebViewClient()

        // Expõe a ponte nativa: o JS chama window.AndroidBridge.pair(...),
        // .injectResolution(...) e .resetResolution()
        webView.addJavascriptInterface(AdbBridge(this, webView), "AndroidBridge")

        // Carrega o app que está empacotado dentro de assets/index.html
        webView.loadUrl("file:///android_asset/index.html")
    }

    // Faz o botão "voltar" do Android fechar o teclado/editor do app
    // em vez de sair direto, se o WebView tiver histórico de navegação.
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
