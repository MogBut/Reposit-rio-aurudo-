package com.noturno.app

import android.webkit.JavascriptInterface
import android.webkit.WebView
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

/**
 * Ponte exposta ao JavaScript da página (window.AndroidBridge.*).
 *
 * Usa a biblioteca "dadb" (dev.mobile:dadb / dadb-android), a mesma usada
 * por ferramentas como o Maestro, para falar o protocolo ADB sem precisar
 * do binário adb nem de um servidor adb rodando no PC.
 *
 * IMPORTANTE: não foi possível compilar/testar este arquivo neste ambiente
 * (sem SDK Android disponível aqui). O FLUXO está correto (parear -> trocar
 * para a porta de conexão -> abrir shell -> rodar "wm size"/"wm density"),
 * mas os nomes exatos de 2 ou 3 métodos (marcados abaixo com "// confira")
 * podem variar um pouco entre versões da lib — o autocomplete do Android
 * Studio resolve isso na hora.
 */
class AdbBridge(private val activity: MainActivity, private val webView: WebView) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var dadb: Dadb? = null
    private var keyPair: AdbKeyPair? = null

    @JavascriptInterface
    fun pair(pairHost: String, pairPort: String, code: String, connHost: String, connPort: String) {
        scope.launch {
            try {
                emit("pairing", "pareando com $pairHost:$pairPort...")
                val kp = getOrCreateKeyPair()

                // confira: em algumas versões é Dadb.pair(host, port, pairCode, keyPair)
                Dadb.pair(pairHost, pairPort.toInt(), code, kp)

                emit("connecting", "pareado! conectando em $connHost:$connPort...")
                val d = Dadb.create(connHost, connPort.toInt(), kp)
                dadb = d
                emit("connected", "conectado com sucesso")
            } catch (e: Exception) {
                emit("error", "erro ao parear/conectar: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun injectResolution(resolution: String, density: String) {
        scope.launch {
            val ok1 = runShell("wm size $resolution")
            val ok2 = runShell("wm density $density")
            if (ok1 && ok2) emit("done", "resolução $resolution @ ${density}dpi aplicada")
        }
    }

    @JavascriptInterface
    fun resetResolution() {
        scope.launch {
            val ok1 = runShell("wm size reset")
            val ok2 = runShell("wm density reset")
            if (ok1 && ok2) emit("done", "resolução e densidade resetadas para o padrão")
        }
    }

    private fun runShell(cmd: String): Boolean {
        val d = dadb
        if (d == null) {
            emit("error", "não conectado — pareie primeiro")
            return false
        }
        return try {
            val result = d.shell(cmd)
            emit("done", "$ $cmd  (saída ${result.exitCode})")
            result.exitCode == 0
        } catch (e: Exception) {
            emit("error", "falha em '$cmd': ${e.message}")
            false
        }
    }

    /**
     * A chave RSA precisa ser a MESMA usada no pareamento e na conexão —
     * é o que prova ao celular que é o mesmo "cliente" dos dois lados.
     * Guardamos ela nos arquivos privados do app para reusar entre sessões.
     */
    private fun getOrCreateKeyPair(): AdbKeyPair {
        keyPair?.let { return it }
        val dir = activity.filesDir
        val priv = File(dir, "adb_key")
        val pub = File(dir, "adb_key.pub")

        val kp = if (priv.exists() && pub.exists()) {
            AdbKeyPair.read(priv, pub)
        } else {
            // confira: o nome pode ser AdbKeyPair.generate() ou similar
            val generated = AdbKeyPair.generate()
            // confira: método de salvar em arquivo pode se chamar write(...)/save(...)
            generated.write(priv, pub)
            generated
        }
        keyPair = kp
        return kp
    }

    private fun emit(type: String, message: String) {
        activity.runOnUiThread {
            val safeMsg = JSONObject.quote(message)
            webView.evaluateJavascript(
                "window.onAdbEvent && window.onAdbEvent('$type', $safeMsg)", null
            )
        }
    }
}
